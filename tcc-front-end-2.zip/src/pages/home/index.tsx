import React from 'react';

const Home = () => {
    return (
        <h1>
            1HOME - 2HOME - 3HOME - 4HOME - 5HOME
        </h1>
    )

}

export default Home;