import React from 'react';
import { Outlet } from "react-router-dom"

const LoginLayout = () => {
    alert("entrou para login")
    return <Outlet />

}

export default LoginLayout