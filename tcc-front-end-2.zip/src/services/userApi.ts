export interface Test {
  teste: String;
}
